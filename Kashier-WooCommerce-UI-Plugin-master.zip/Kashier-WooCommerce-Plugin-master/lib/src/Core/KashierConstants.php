<?php

namespace ITeam\Kashier\Core;

/**
 * Class KashierConstants
 * Placeholder for Kashier Constants
 *
 * @package ITeam\Kashier\Core
 */
class KashierConstants
{
    const SDK_NAME = 'Kashier-PHP-SDK';
    const SDK_VERSION = '1.0.0';

    const IFRAME_BASE_URL = 'https://d1vpaq3sx4yj6p.cloudfront.net';

}
